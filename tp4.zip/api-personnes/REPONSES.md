# REPONSES.md – TP4 & TP4.5 : API RESTful avec Express JS

**Matière :** SoA et Microservices  
**Classe :** 4Info – A.U. 2025/2026  
**Enseignant :** Dr. Salah Gontara

---

## TP4 – Création d'une API RESTful avec Express JS

### Étape 1 – Initialisation du projet

```bash
mkdir api-personnes && cd api-personnes
npm init -y
npm install express sqlite3 cors express-rate-limit swagger-ui-express yamljs
```

Structure du projet créée :
```
api-personnes/
├── index.js            ← serveur principal + routes
├── database.js         ← connexion SQLite + création table
├── openapi.yaml        ← spécification OpenAPI 3.0 (Swagger)
├── keycloak-config.json← config OAuth 2.0 Keycloak
├── test-cors.html      ← test CORS dans le navigateur
└── package.json
```

---

### Étape 2 – Configuration de SQLite3 (`database.js`)

Le fichier `database.js` :
- Crée (ou ouvre) le fichier `maBaseDeDonnees.sqlite`
- Crée la table `personnes` avec les colonnes `id`, `nom`, `adresse` (étape 4 intégrée directement)
- Insère 3 personnes initiales **uniquement si la table est vide** (protection contre les doublons au redémarrage)

```js
const db = new sqlite3.Database('./maBaseDeDonnees.sqlite',
  sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, callback);
```

---

### Étape 3 & 4 – Routes CRUD + colonne `adresse`

L'API expose les 5 routes suivantes sur la ressource `/personnes` :

| Méthode | Route            | Action                   | Code succès |
|---------|------------------|--------------------------|-------------|
| GET     | `/personnes`     | Lister toutes            | 200         |
| GET     | `/personnes/:id` | Obtenir par ID           | 200         |
| POST    | `/personnes`     | Créer une personne       | 201         |
| PUT     | `/personnes/:id` | Modifier une personne    | 200         |
| DELETE  | `/personnes/:id` | Supprimer une personne   | 200         |

**Bonnes pratiques REST appliquées :**
- Codes HTTP sémantiques : `201 Created`, `400 Bad Request`, `404 Not Found`, `500 Internal Server Error`
- Validation des entrées : `nom` obligatoire, `id` doit être entier
- Réponses JSON uniformes : `{ message, data }` pour les succès, `{ error }` pour les échecs
- Pas d'insertion de doublons au redémarrage (vérification `COUNT(*)`)

---

### Étape 5 – Tests Postman

**Configuration Postman :**
- URL de base : `http://localhost:3000`
- Header sur les requêtes POST/PUT : `Content-Type: application/json`

#### GET /personnes – Lister toutes les personnes
```
GET http://localhost:3000/personnes
```
Réponse attendue :
```json
{
  "message": "success",
  "data": [
    { "id": 1, "nom": "Bob",     "adresse": "12 Rue de la Paix, Paris" },
    { "id": 2, "nom": "Alice",   "adresse": "5 Avenue des Fleurs, Lyon" },
    { "id": 3, "nom": "Charlie", "adresse": "8 Boulevard Victor Hugo, Marseille" }
  ]
}
```

#### GET /personnes/1 – Obtenir une personne
```
GET http://localhost:3000/personnes/1
```
Réponse :
```json
{ "message": "success", "data": { "id": 1, "nom": "Bob", "adresse": "12 Rue de la Paix, Paris" } }
```

#### POST /personnes – Créer une personne
```
POST http://localhost:3000/personnes
Body (JSON) : { "nom": "Fatima", "adresse": "3 Rue de Carthage, Tunis" }
```
Réponse :
```json
{ "message": "success", "data": { "id": 4, "nom": "Fatima", "adresse": "3 Rue de Carthage, Tunis" } }
```

#### PUT /personnes/1 – Modifier une personne
```
PUT http://localhost:3000/personnes/1
Body (JSON) : { "nom": "Bob Dupont", "adresse": "15 Rue Rivoli, Paris" }
```
Réponse :
```json
{ "message": "success", "data": { "id": 1, "nom": "Bob Dupont", "adresse": "15 Rue Rivoli, Paris" } }
```

#### DELETE /personnes/4 – Supprimer une personne
```
DELETE http://localhost:3000/personnes/4
```
Réponse :
```json
{ "message": "success", "data": { "deleted_id": 4 } }
```

#### Cas d'erreur – nom manquant (POST)
```
POST http://localhost:3000/personnes
Body (JSON) : { "adresse": "Tunis" }
```
Réponse (HTTP 400) :
```json
{ "error": "Le champ \"nom\" est obligatoire." }
```

#### Cas d'erreur – ID inexistant (GET)
```
GET http://localhost:3000/personnes/999
```
Réponse (HTTP 404) :
```json
{ "error": "Personne avec l'ID 999 introuvable." }
```

---

### Étape 6 (optionnelle) – OAuth 2.0 avec Keycloak

#### Lancement de Keycloak via Docker

```bash
docker run -p 8080:8080 \
  -e KEYCLOAK_ADMIN=admin \
  -e KEYCLOAK_ADMIN_PASSWORD=admin \
  -v keycloak_data:/opt/keycloak/data \
  quay.io/keycloak/keycloak:latest start-dev
```

Accéder à la console d'administration : **http://localhost:8080/**  
Identifiants : `admin` / `admin`

#### Configuration du Realm et du Client

1. **Créer un Realm** : Administration → Create Realm → Nom : `api-realm` → Create
2. **Créer un Client** :
   - Clients → Create client
   - Client ID : `api-personne`
   - Protocol : `OpenID Connect`
   - Authentication flow : activer **Direct access grants** (pour tester avec Postman)
   - Client authentication : **ON** (confidential client)
   - Valid redirect URIs : `http://localhost:3000/*`
   - Web origins : `http://localhost:3000`
3. **Récupérer le secret** : Clients → api-personne → Credentials → Client Secret
4. **Créer un utilisateur test** : Users → Add user → Username : `testuser` → Set Password

Le fichier `keycloak-config.json` fourni utilise le secret :  
`lmMqDHxDIwXzO6GITSQHs61z47w8r7JQ`

#### Obtenir un token avec Postman

```
POST http://localhost:8080/realms/api-realm/protocol/openid-connect/token
Content-Type: application/x-www-form-urlencoded

grant_type    = password
client_id     = api-personne
client_secret = lmMqDHxDIwXzO6GITSQHs61z47w8r7JQ
username      = testuser
password      = <mot-de-passe>
```

Réponse : un `access_token` JWT à utiliser dans les requêtes protégées :
```
Authorization: Bearer <access_token>
```

#### Activer Keycloak dans `index.js`

Décommenter les blocs commentés dans `index.js` :
```js
const session  = require('express-session');
const Keycloak = require('keycloak-connect');
// ...
app.use(keycloak.middleware());

// Protéger une route :
app.get('/personnes', keycloak.protect(), (req, res) => { ... });
```

---

### Étape 7 (optionnelle) – Swagger UI

Swagger UI accessible à : **http://localhost:3000/api-docs**

Le fichier `openapi.yaml` documente :
- Toutes les routes CRUD (`/personnes`, `/personnes/{id}`)
- Les schémas de requête/réponse (`Personne`, `PersonneInput`, `Erreur`, `ErreurRateLimit`)
- Les codes HTTP possibles (200, 201, 400, 404, 429, 500)

```js
const swaggerUi  = require('swagger-ui-express');
const YAML       = require('yamljs');
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(YAML.load('./openapi.yaml')));
```

---

## TP4.5 – Rate Limiting et CORS

### CORS (Cross-Origin Resource Sharing)

**Rôle :** Autorise les navigateurs à faire des requêtes vers une API depuis une origine différente.  
Sans CORS, le navigateur bloque les requêtes JavaScript vers `http://localhost:3000` depuis une autre origine.

**Configuration appliquée :**
```js
const cors = require('cors');

// Autoriser toutes les origines (développement)
app.use(cors());

// Production – restreindre aux origines connues :
// app.use(cors({ origin: ['http://localhost:4200', 'https://monapp.com'] }));
```

**Test CORS :**  
Ouvrir `test-cors.html` dans un navigateur → cliquer le bouton → les données s'affichent si le CORS fonctionne.

### Rate Limiting (Limitation de requêtes)

**Rôle :** Protège l'API contre les abus (attaques par déni de service, scraping, brute force).  
Limite chaque IP à **100 requêtes par fenêtre de 15 minutes**.

```js
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 100,
  standardHeaders: true,
  message: {
    status: 429,
    error: 'Trop de requêtes effectuées depuis cette IP, veuillez réessayer après 15 minutes.'
  }
});
app.use(limiter);
```

**Test Rate Limiting avec Postman :**  
Utiliser le Runner Postman pour envoyer 101 requêtes consécutives vers `GET /personnes`.  
Dès la 101ème requête, réponse HTTP 429 :
```json
{
  "status": 429,
  "error": "Trop de requêtes effectuées depuis cette IP, veuillez réessayer après 15 minutes."
}
```

Les en-têtes de réponse indiquent l'état du rate limit :
```
RateLimit-Limit:     100
RateLimit-Remaining: 0
RateLimit-Reset:     <timestamp>
```

### Analyse comparée CORS vs Rate Limiting

| Critère        | CORS                               | Rate Limiting                        |
|----------------|------------------------------------|--------------------------------------|
| Objectif       | Contrôle des origines autorisées   | Contrôle du volume de requêtes       |
| Niveau         | Navigateur (en-têtes HTTP)         | Serveur (compteur par IP)            |
| Erreur         | Bloqué par le navigateur           | HTTP 429 Too Many Requests           |
| Protection     | Accès cross-domain non autorisé    | Abus, DDoS, brute force              |

---

## Démarrage de l'application

```bash
# Installer les dépendances
npm install

# Lancer le serveur
node index.js
```

Sorties console attendues :
```
✅ Connecté à la base de données SQLite.
✅ Table "personnes" prête.
✅ Données initiales insérées.
🚀 Serveur démarré sur http://localhost:3000
📄 Swagger UI : http://localhost:3000/api-docs
```
