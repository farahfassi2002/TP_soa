const sqlite3 = require('sqlite3').verbose();

/**
 * Connexion à la base de données SQLite.
 * Le fichier maBaseDeDonnees.sqlite est créé automatiquement s'il n'existe pas.
 * Flags :
 *   OPEN_READWRITE – permet la lecture et l'écriture
 *   OPEN_CREATE    – crée le fichier s'il est absent
 */
const db = new sqlite3.Database(
  './maBaseDeDonnees.sqlite',
  sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE,
  (err) => {
    if (err) {
      console.error('Erreur de connexion SQLite :', err.message);
    } else {
      console.log('✅ Connecté à la base de données SQLite.');

      // Étape 4 : la table inclut désormais la colonne "adresse"
      db.run(
        `CREATE TABLE IF NOT EXISTS personnes (
          id      INTEGER PRIMARY KEY AUTOINCREMENT,
          nom     TEXT NOT NULL,
          adresse TEXT
        )`,
        (err) => {
          if (err) {
            console.error('Erreur création table :', err.message);
          } else {
            console.log('✅ Table "personnes" prête.');

            // Données initiales : insérées seulement si la table est vide
            db.get('SELECT COUNT(*) AS count FROM personnes', (err, row) => {
              if (!err && row.count === 0) {
                const personnes = [
                  { nom: 'Bob',     adresse: '12 Rue de la Paix, Paris' },
                  { nom: 'Alice',   adresse: '5 Avenue des Fleurs, Lyon' },
                  { nom: 'Charlie', adresse: '8 Boulevard Victor Hugo, Marseille' },
                ];
                const stmt = db.prepare(
                  'INSERT INTO personnes (nom, adresse) VALUES (?, ?)'
                );
                personnes.forEach(({ nom, adresse }) => stmt.run(nom, adresse));
                stmt.finalize();
                console.log('✅ Données initiales insérées.');
              }
            });
          }
        }
      );
    }
  }
);

module.exports = db;
