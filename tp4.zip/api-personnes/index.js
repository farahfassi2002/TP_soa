// ============================================================
// TP4 + TP4.5 : API RESTful – Personnes
// Stack : Express JS · SQLite3 · CORS · Rate Limiting
//         Keycloak (OAuth 2.0) · Swagger UI (OpenAPI 3.0)
// ============================================================

const express  = require('express');
const cors     = require('cors');
const rateLimit = require('express-rate-limit');
const db       = require('./database');

// --- Swagger (TP4 étape 7 optionnelle) ----------------------
const swaggerUi = require('swagger-ui-express');
const YAML      = require('yamljs');
const swaggerDoc = YAML.load('./openapi.yaml');

// --- Keycloak (TP4 étape 6 optionnelle) ---------------------
// Décommenter les lignes ci-dessous si Keycloak est démarré
// const session  = require('express-session');
// const Keycloak = require('keycloak-connect');
// const memoryStore = new session.MemoryStore();

const app  = express();
const PORT = 3000;

// ============================================================
// MIDDLEWARES GLOBAUX
// ============================================================

// 1. Parser JSON
app.use(express.json());

// 2. CORS – TP4.5 ─────────────────────────────────────────
//    Autorise toutes les origines (développement).
//    Pour la production, restreindre :
//    app.use(cors({ origin: ['http://localhost:4200'] }));
app.use(cors());

// 3. Rate Limiting – TP4.5 ────────────────────────────────
//    100 requêtes par IP par fenêtre de 15 minutes
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes en millisecondes
  max: 100,
  standardHeaders: true,      // Ajoute les en-têtes RateLimit-* standard
  legacyHeaders: false,
  message: {
    status: 429,
    error: 'Trop de requêtes effectuées depuis cette IP, veuillez réessayer après 15 minutes.'
  }
});
app.use(limiter);

// 4. Keycloak (décommenter si Keycloak est actif) ──────────
// app.use(session({
//   secret: 'api-secret',
//   resave: false,
//   saveUninitialized: true,
//   store: memoryStore
// }));
// const keycloak = new Keycloak({ store: memoryStore }, './keycloak-config.json');
// app.use(keycloak.middleware());

// 5. Swagger UI ─────────────────────────────────────────────
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDoc));

// ============================================================
// ROUTES
// ============================================================

// --- Racine -------------------------------------------------
app.get('/', (req, res) => {
  res.json({
    message: 'Registre de personnes ! Choisissez le bon routage !',
    routes: {
      'GET  /personnes'       : 'Lister toutes les personnes',
      'GET  /personnes/:id'   : 'Obtenir une personne par ID',
      'POST /personnes'       : 'Créer une nouvelle personne',
      'PUT  /personnes/:id'   : 'Modifier une personne',
      'DELETE /personnes/:id' : 'Supprimer une personne',
      'GET  /api-docs'        : 'Documentation Swagger',
    }
  });
});

// --- GET /personnes – Lister toutes les personnes -----------
// Pour sécuriser avec Keycloak : app.get('/personnes', keycloak.protect(), ...)
app.get('/personnes', (req, res) => {
  db.all('SELECT * FROM personnes', [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: 'success', data: rows });
  });
});

// --- GET /personnes/:id – Obtenir une personne par ID -------
app.get('/personnes/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);

  if (isNaN(id)) {
    return res.status(400).json({ error: 'L\'identifiant doit être un entier.' });
  }

  db.get('SELECT * FROM personnes WHERE id = ?', [id], (err, row) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (!row) {
      return res.status(404).json({ error: `Personne avec l'ID ${id} introuvable.` });
    }
    res.json({ message: 'success', data: row });
  });
});

// --- POST /personnes – Créer une nouvelle personne ----------
app.post('/personnes', (req, res) => {
  const { nom, adresse } = req.body;

  if (!nom || nom.trim() === '') {
    return res.status(400).json({ error: 'Le champ "nom" est obligatoire.' });
  }

  db.run(
    'INSERT INTO personnes (nom, adresse) VALUES (?, ?)',
    [nom.trim(), adresse || null],
    function (err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.status(201).json({
        message: 'success',
        data: { id: this.lastID, nom: nom.trim(), adresse: adresse || null }
      });
    }
  );
});

// --- PUT /personnes/:id – Modifier une personne -------------
app.put('/personnes/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { nom, adresse } = req.body;

  if (isNaN(id)) {
    return res.status(400).json({ error: 'L\'identifiant doit être un entier.' });
  }
  if (!nom || nom.trim() === '') {
    return res.status(400).json({ error: 'Le champ "nom" est obligatoire.' });
  }

  db.run(
    'UPDATE personnes SET nom = ?, adresse = ? WHERE id = ?',
    [nom.trim(), adresse || null, id],
    function (err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      if (this.changes === 0) {
        return res.status(404).json({ error: `Personne avec l'ID ${id} introuvable.` });
      }
      res.json({ message: 'success', data: { id, nom: nom.trim(), adresse: adresse || null } });
    }
  );
});

// --- DELETE /personnes/:id – Supprimer une personne ---------
app.delete('/personnes/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);

  if (isNaN(id)) {
    return res.status(400).json({ error: 'L\'identifiant doit être un entier.' });
  }

  db.run('DELETE FROM personnes WHERE id = ?', [id], function (err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: `Personne avec l'ID ${id} introuvable.` });
    }
    res.json({ message: 'success', data: { deleted_id: id } });
  });
});

// --- Route sécurisée Keycloak (exemple) ---------------------
// app.get('/secure', keycloak.protect(), (req, res) => {
//   res.json({ message: 'Vous êtes authentifié via Keycloak !' });
// });

// ============================================================
// DÉMARRAGE DU SERVEUR
// ============================================================
app.listen(PORT, () => {
  console.log(`🚀 Serveur démarré sur http://localhost:${PORT}`);
  console.log(`📄 Swagger UI : http://localhost:${PORT}/api-docs`);
});
