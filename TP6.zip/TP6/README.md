# TP6 — Création d'une API REST & GraphQL avec RxDB

> **Matière :** Architecture Orientée Service  
> **Enseignant :** Salah Gontara  
> **Classe :** 4Info — A.U. 2025/2026

---

## Table des matières

1. [Objectifs](#objectifs)  
2. [Architecture du projet](#architecture-du-projet)  
3. [Technologies utilisées](#technologies-utilisées)  
4. [Installation et démarrage](#installation-et-démarrage)  
5. [Modèle de données](#modèle-de-données)  
6. [API REST — Endpoints](#api-rest--endpoints)  
7. [API GraphQL — Opérations](#api-graphql--opérations)  
8. [Refactorisation et séparation des responsabilités](#refactorisation-et-séparation-des-responsabilités)  
9. [Tests effectués](#tests-effectués)  
10. [Difficultés rencontrées](#difficultés-rencontrées)  
11. [Conclusion](#conclusion)

---

## Objectifs

- Créer une **API REST** complète (CRUD) sur les ressources `User` et `Device`.  
- Créer un **service GraphQL** pour les mêmes opérations CRUD.  
- Utiliser **RxDB** (base NoSQL orientée documents) pour la persistance.  
- Garantir qu'un **Device** ne peut pas exister sans son utilisateur (composition).  
- Assurer la **suppression en cascade** des devices lors de la suppression d'un utilisateur.  
- Partager la **même logique métier** entre REST et GraphQL via des services dédiés.

---

## Architecture du projet

```
api-rest-graphql-rxdb/
│
├── server.js            # Point d'entrée : Express + GraphQL + montage des routes
├── db.js                # Initialisation RxDB (collections users & devices, snapshots JSON)
├── schema.gql           # Schéma GraphQL (types, queries, mutations)
│
├── services/
│   ├── userService.js   # Logique métier utilisateurs (CRUD + unicité email)
│   └── deviceService.js # Logique métier devices (CRUD + validation + composition)
│
├── resolvers/
│   ├── userResolver.js  # Résolveurs GraphQL → userService
│   └── deviceResolver.js# Résolveurs GraphQL → deviceService
│
├── routes/
│   ├── userRoutes.js    # Routes REST /users → userService
│   └── deviceRoutes.js  # Routes REST /devices → deviceService
│
└── data/
    ├── users.snapshot.json    # Persistance disque des utilisateurs
    └── devices.snapshot.json  # Persistance disque des devices
```

### Diagramme de flux

```
Client (Postman / curl / navigateur)
        │
        ├── REST  → routes/*.js  → services/*.js → RxDB
        └── GraphQL → resolvers/*.js → services/*.js → RxDB
```

---

## Technologies utilisées

| Rôle | Technologie |
|---|---|
| Serveur HTTP | Node.js, Express 4 |
| API GraphQL | `graphql`, `graphql-http` |
| Base de données | RxDB 15 (stockage mémoire + snapshot JSON) |
| Réactivité | RxJS 7 |
| Stockage en mémoire | `rxdb/plugins/storage-memory` |
| Validation | `rxdb/plugins/validate-ajv` |
| Test API | Postman / curl |

---

## Installation et démarrage

```bash
# 1. Cloner le dépôt
git clone <url-du-repo>
cd api-rest-graphql-rxdb

# 2. Installer les dépendances
npm install

# 3. Démarrer le serveur
node server.js
```

Le serveur écoute sur **http://localhost:5000**  
GraphQL est disponible sur **http://localhost:5000/graphql**

---

## Modèle de données

### User

| Champ | Type | Contraintes |
|---|---|---|
| `id` | String (UUID) | Clé primaire, généré automatiquement |
| `name` | String | 1–120 caractères, obligatoire |
| `email` | String | 3–190 caractères, unique, obligatoire |
| `password` | String | 1–255 caractères, obligatoire |

### Device

| Champ | Type | Contraintes |
|---|---|---|
| `id` | String (UUID) | Clé primaire, généré automatiquement |
| `userId` | String | Référence obligatoire vers un `User` existant |
| `name` | String | 1–120 caractères, obligatoire |
| `type` | String | `laptop`, `smartphone`, `tablet`, `server` |
| `serialNumber` | String | 1–100 caractères, obligatoire |
| `status` | String | `active`, `inactive`, `maintenance` |

**Relation de composition :** un Device ne peut pas exister sans son User. La suppression d'un User entraîne automatiquement la suppression de tous ses Devices.

---

## API REST — Endpoints

### Utilisateurs

| Méthode | Route | Description |
|---|---|---|
| `GET` | `/users` | Liste tous les utilisateurs |
| `GET` | `/users/:id` | Récupère un utilisateur par ID |
| `POST` | `/users` | Crée un nouvel utilisateur |
| `PUT` | `/users/:id` | Met à jour un utilisateur |
| `DELETE` | `/users/:id` | Supprime un utilisateur (+ ses devices) |

#### Exemple — Créer un utilisateur

```bash
curl -X POST http://localhost:5000/users \
  -H "Content-Type: application/json" \
  -d '{"name":"Ali Ben Salah","email":"ali@example.com","password":"123456"}'
```

**Réponse 201 :**
```json
{
  "id": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "name": "Ali Ben Salah",
  "email": "ali@example.com",
  "password": "123456"
}
```

#### Exemple — Lister les utilisateurs

```bash
curl http://localhost:5000/users
```

#### Exemple — Mettre à jour

```bash
curl -X PUT http://localhost:5000/users/<id> \
  -H "Content-Type: application/json" \
  -d '{"name":"Ali B.","email":"ali.b@example.com","password":"newpass"}'
```

#### Exemple — Supprimer

```bash
curl -X DELETE http://localhost:5000/users/<id>
```

---

### Devices

| Méthode | Route | Description |
|---|---|---|
| `GET` | `/devices` | Liste tous les devices |
| `GET` | `/devices/:id` | Récupère un device par ID |
| `GET` | `/devices/by-user/:userId` | Devices d'un utilisateur donné |
| `POST` | `/devices` | Crée un device (userId obligatoire) |
| `PUT` | `/devices/:id` | Met à jour un device |
| `DELETE` | `/devices/:id` | Supprime un device |

#### Exemple — Créer un device

```bash
curl -X POST http://localhost:5000/devices \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "<id-utilisateur>",
    "name": "Mon Laptop",
    "type": "laptop",
    "serialNumber": "SN-2024-001",
    "status": "active"
  }'
```

**Erreur si userId inexistant (400) :**
```json
{ "error": "Utilisateur introuvable (id: xxx)" }
```

---

## API GraphQL — Opérations

Toutes les requêtes sont envoyées via `POST /graphql` avec `Content-Type: application/json`.

### Queries

#### Lister tous les utilisateurs (avec leurs devices)

```graphql
{
  users {
    id
    name
    email
    devices {
      id
      name
      type
      status
    }
  }
}
```

#### Récupérer un utilisateur

```graphql
{
  user(id: "<id>") {
    id
    name
    email
  }
}
```

#### Lister tous les devices

```graphql
{
  devices {
    id
    name
    type
    serialNumber
    status
    userId
  }
}
```

#### Devices d'un utilisateur

```graphql
{
  devicesByUser(userId: "<id>") {
    id
    name
    type
    status
  }
}
```

---

### Mutations

#### Ajouter un utilisateur

```graphql
mutation {
  addUser(name: "Amira Khelif", email: "amira@example.com", password: "abc123") {
    id
    name
    email
  }
}
```

#### Mettre à jour un utilisateur

```graphql
mutation {
  updateUser(id: "<id>", name: "Amira K.", email: "amira.k@example.com", password: "xyz789") {
    id
    name
    email
  }
}
```

#### Supprimer un utilisateur

```graphql
mutation {
  deleteUser(id: "<id>")
}
```

#### Ajouter un device

```graphql
mutation {
  addDevice(
    userId: "<id-utilisateur>"
    name: "Serveur principal"
    type: "server"
    serialNumber: "SRV-2024-042"
    status: "active"
  ) {
    id
    name
    type
    status
  }
}
```

#### Mettre à jour un device

```graphql
mutation {
  updateDevice(
    id: "<id-device>"
    name: "Serveur principal v2"
    type: "server"
    serialNumber: "SRV-2024-042"
    status: "maintenance"
  ) {
    id
    name
    status
  }
}
```

#### Supprimer un device

```graphql
mutation {
  deleteDevice(id: "<id-device>")
}
```

---

## Refactorisation et séparation des responsabilités

La refactorisation suit le principe de **séparation des préoccupations** :

| Couche | Fichier(s) | Rôle |
|---|---|---|
| **Accès aux données** | `db.js` | Connexion RxDB, schémas, persistance JSON |
| **Logique métier** | `services/userService.js`, `services/deviceService.js` | CRUD, validation, règles métier, suppression en cascade |
| **Résolveurs GraphQL** | `resolvers/userResolver.js`, `resolvers/deviceResolver.js` | Adaptation GraphQL → services |
| **Routes REST** | `routes/userRoutes.js`, `routes/deviceRoutes.js` | Adaptation HTTP → services |
| **Point d'entrée** | `server.js` | Composition du serveur Express + GraphQL |

Cette architecture garantit que :
- La logique de validation (unicité email, type de device valide) est écrite **une seule fois** dans les services.
- Ajouter une nouvelle interface (ex. WebSocket) ne nécessite que d'appeler les mêmes services.
- Les tests unitaires peuvent cibler les services indépendamment du transport HTTP/GraphQL.

---

## Tests effectués

### Scénario 1 — Interopérabilité REST → GraphQL

1. Créer deux utilisateurs via REST :
```bash
curl -X POST http://localhost:5000/users -H "Content-Type: application/json" \
  -d '{"name":"User REST 1","email":"user1@test.com","password":"pass1"}'

curl -X POST http://localhost:5000/users -H "Content-Type: application/json" \
  -d '{"name":"User REST 2","email":"user2@test.com","password":"pass2"}'
```

2. Vérifier leur présence via GraphQL :
```graphql
{ users { id name email } }
```
✅ Les deux utilisateurs créés via REST sont bien visibles via GraphQL.

---

### Scénario 2 — Interopérabilité GraphQL → REST

1. Créer un utilisateur via GraphQL :
```graphql
mutation {
  addUser(name: "User GraphQL", email: "graphql@test.com", password: "gpass") { id }
}
```

2. Vérifier via REST :
```bash
curl http://localhost:5000/users
```
✅ L'utilisateur créé via GraphQL est bien visible via REST.

---

### Scénario 3 — Composition User / Device

1. Créer un device avec un `userId` valide → ✅ Succès (201)  
2. Créer un device avec un `userId` inexistant → ✅ Erreur 400 `"Utilisateur introuvable"`  
3. Supprimer l'utilisateur parent → ✅ Ses devices sont supprimés automatiquement  

---

### Scénario 4 — Validation des données

| Test | Résultat |
|---|---|
| Email en doublon (REST) | ❌ 400 `"Adresse e-mail déjà utilisée"` |
| Email en doublon (GraphQL) | ❌ Erreur GraphQL retournée |
| Type de device invalide | ❌ 400 `"Type invalide. Valeurs acceptées : laptop, smartphone, tablet, server"` |
| Statut de device invalide | ❌ 400 `"Statut invalide..."` |
| Suppression d'un ID inexistant | ❌ 404 `"Utilisateur non trouvé"` |

---

## Difficultés rencontrées

| Difficulté | Solution apportée |
|---|---|
| RxDB nécessite une fonction de hachage personnalisée | Implémentation d'une `hashFunction` avec `crypto.createHash('sha256')` |
| Résolution du champ imbriqué `User.devices` en GraphQL | Utilisation d'une classe `UserWithDevices` avec une méthode `async devices()` |
| Persistance entre redémarrages (RxDB in-memory) | Système de snapshots JSON lus au démarrage et écrits après chaque mutation |
| Suppression en cascade non native dans RxDB | Implémentation manuelle dans `userService.deleteUser` |
| Ordre du middleware `express.json()` | Placé avant les routes pour garantir le parsing du body |

---

## Conclusion

Ce TP a permis de mettre en place une architecture complète combinant **REST** et **GraphQL** sur la même base de données **RxDB**. Les deux interfaces partagent intégralement la logique métier grâce à la couche `services/`, ce qui rend le code maintenable et testable.

La relation de composition entre `User` et `Device` a été correctement implémentée : un device ne peut exister sans utilisateur, et la suppression d'un utilisateur entraîne automatiquement celle de ses devices.

La persistance via des snapshots JSON garantit la durabilité des données entre les redémarrages du serveur malgré l'utilisation d'un stockage en mémoire.
