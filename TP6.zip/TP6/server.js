const fs   = require('fs');
const path = require('path');

const express        = require('express');
const { buildSchema } = require('graphql');
const { createHandler } = require('graphql-http/lib/use/express');

const userResolver   = require('./resolvers/userResolver');
const deviceResolver = require('./resolvers/deviceResolver');
const deviceService  = require('./services/deviceService');
const userRoutes     = require('./routes/userRoutes');
const deviceRoutes   = require('./routes/deviceRoutes');

const app  = express();
const PORT = process.env.PORT || 5000;

// ─── GraphQL ─────────────────────────────────────────────────────────────────

const schema = buildSchema(
  fs.readFileSync(path.join(__dirname, 'schema.gql'), 'utf8')
);

// Résolveur racine : fusion user + device + champ imbriqué User.devices
const rootResolver = {
  ...userResolver,
  ...deviceResolver,
  // Résolution du champ imbriqué User.devices
  // graphql-http appelle cette fonction avec l'objet User comme contexte source
};

// Wrapper pour résoudre User.devices automatiquement
class UserWithDevices {
  constructor(data) {
    Object.assign(this, data);
  }
  async devices() {
    return deviceService.getDevicesByUser(this.id);
  }
}

const rootValue = {
  // ── Queries ──
  user: async ({ id }) => {
    const u = await userResolver.user({ id });
    return u ? new UserWithDevices(u) : null;
  },
  users: async () => {
    const list = await userResolver.users();
    return list.map((u) => new UserWithDevices(u));
  },
  device:        deviceResolver.device,
  devices:       deviceResolver.devices,
  devicesByUser: deviceResolver.devicesByUser,

  // ── Mutations ──
  addUser: async (args) => {
    const u = await userResolver.addUser(args);
    return u ? new UserWithDevices(u) : null;
  },
  updateUser: async (args) => {
    const u = await userResolver.updateUser(args);
    return u ? new UserWithDevices(u) : null;
  },
  deleteUser:   userResolver.deleteUser,
  addDevice:    deviceResolver.addDevice,
  updateDevice: deviceResolver.updateDevice,
  deleteDevice: deviceResolver.deleteDevice,
};

// ─── Middleware ───────────────────────────────────────────────────────────────

app.use(express.json());

// ─── Routes ───────────────────────────────────────────────────────────────────

app.get('/', (req, res) => {
  res.json({
    message: 'TP6 — API REST/GraphQL avec RxDB',
    rest: {
      users:   { list: 'GET /users', one: 'GET /users/:id', create: 'POST /users', update: 'PUT /users/:id', delete: 'DELETE /users/:id' },
      devices: { list: 'GET /devices', byUser: 'GET /devices/by-user/:userId', one: 'GET /devices/:id', create: 'POST /devices', update: 'PUT /devices/:id', delete: 'DELETE /devices/:id' },
    },
    graphql: 'POST /graphql',
  });
});

app.use('/users',   userRoutes);
app.use('/devices', deviceRoutes);

app.all('/graphql', createHandler({ schema, rootValue }));

// ─── Start ───────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`✅  Serveur démarré  →  http://localhost:${PORT}`);
  console.log(`🔷  GraphQL          →  http://localhost:${PORT}/graphql`);
});
