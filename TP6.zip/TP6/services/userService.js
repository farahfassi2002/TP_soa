/**
 * userService.js
 * Logique métier pour les utilisateurs.
 * Réutilisée par les routes REST et les résolveurs GraphQL.
 */

const dbPromise = require('../db');

function toJson(doc) {
  return doc ? doc.toJSON() : null;
}

async function findByEmail(usersCollection, email) {
  return usersCollection.findOne({ selector: { email } }).exec();
}

async function ensureUniqueEmail(usersCollection, email, excludedId = null) {
  const existing = await findByEmail(usersCollection, email);
  if (existing && existing.primary !== excludedId) {
    throw new Error('Adresse e-mail déjà utilisée');
  }
}

// ─── CRUD ────────────────────────────────────────────────────────────────────

async function getUser(id) {
  const { users } = await dbPromise;
  const doc = await users.findOne(id).exec();
  return toJson(doc);
}

async function getUsers() {
  const { users } = await dbPromise;
  const docs = await users.find().exec();
  return docs.map((d) => d.toJSON());
}

async function createUser({ name, email, password }) {
  const { users, persistUsers, createId } = await dbPromise;
  await ensureUniqueEmail(users, email);
  const inserted = await users.insert({ id: createId(), name, email, password });
  await persistUsers();
  return inserted.toJSON();
}

async function updateUser({ id, name, email, password }) {
  const { users, persistUsers } = await dbPromise;
  const doc = await users.findOne(id).exec();
  if (!doc) return null;
  await ensureUniqueEmail(users, email, id);
  const updated = await doc.incrementalPatch({ name, email, password });
  await persistUsers();
  return updated.toJSON();
}

async function deleteUser(id) {
  const { users, devices, persistUsers, persistDevices } = await dbPromise;
  const doc = await users.findOne(id).exec();
  if (!doc) return false;

  // Suppression en cascade des devices liés
  const userDevices = await devices.find({ selector: { userId: id } }).exec();
  await Promise.all(userDevices.map((d) => d.remove()));
  await persistDevices();

  await doc.remove();
  await persistUsers();
  return true;
}

module.exports = { getUser, getUsers, createUser, updateUser, deleteUser };
