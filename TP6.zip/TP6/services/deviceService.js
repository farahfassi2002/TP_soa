/**
 * deviceService.js
 * Logique métier pour les devices.
 * Réutilisée par les routes REST et les résolveurs GraphQL.
 */

const dbPromise = require('../db');

const VALID_TYPES   = ['laptop', 'smartphone', 'tablet', 'server'];
const VALID_STATUSES = ['active', 'inactive', 'maintenance'];

function toJson(doc) {
  return doc ? doc.toJSON() : null;
}

function validateDevice({ type, status }) {
  if (!VALID_TYPES.includes(type))
    throw new Error(`Type invalide. Valeurs acceptées : ${VALID_TYPES.join(', ')}`);
  if (!VALID_STATUSES.includes(status))
    throw new Error(`Statut invalide. Valeurs acceptées : ${VALID_STATUSES.join(', ')}`);
}

// ─── CRUD ────────────────────────────────────────────────────────────────────

async function getDevice(id) {
  const { devices } = await dbPromise;
  const doc = await devices.findOne(id).exec();
  return toJson(doc);
}

async function getDevices() {
  const { devices } = await dbPromise;
  const docs = await devices.find().exec();
  return docs.map((d) => d.toJSON());
}

async function getDevicesByUser(userId) {
  const { devices } = await dbPromise;
  const docs = await devices.find({ selector: { userId } }).exec();
  return docs.map((d) => d.toJSON());
}

async function createDevice({ userId, name, type, serialNumber, status }) {
  const { users, devices, persistDevices, createId } = await dbPromise;

  // Vérifier que l'utilisateur existe (composition)
  const userDoc = await users.findOne(userId).exec();
  if (!userDoc) throw new Error(`Utilisateur introuvable (id: ${userId})`);

  validateDevice({ type, status });

  const inserted = await devices.insert({
    id: createId(),
    userId,
    name,
    type,
    serialNumber,
    status,
  });
  await persistDevices();
  return inserted.toJSON();
}

async function updateDevice({ id, name, type, serialNumber, status }) {
  const { devices, persistDevices } = await dbPromise;
  const doc = await devices.findOne(id).exec();
  if (!doc) return null;

  validateDevice({ type, status });

  const updated = await doc.incrementalPatch({ name, type, serialNumber, status });
  await persistDevices();
  return updated.toJSON();
}

async function deleteDevice(id) {
  const { devices, persistDevices } = await dbPromise;
  const doc = await devices.findOne(id).exec();
  if (!doc) return false;
  await doc.remove();
  await persistDevices();
  return true;
}

module.exports = {
  getDevice,
  getDevices,
  getDevicesByUser,
  createDevice,
  updateDevice,
  deleteDevice,
};
