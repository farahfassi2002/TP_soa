/**
 * routes/deviceRoutes.js
 * Routes REST pour les devices — délèguent à deviceService.
 */

const { Router } = require('express');
const deviceService = require('../services/deviceService');

const router = Router();

// GET /devices
router.get('/', async (req, res) => {
  const devices = await deviceService.getDevices();
  res.json(devices);
});

// GET /devices/:id
router.get('/:id', async (req, res) => {
  const device = await deviceService.getDevice(req.params.id);
  if (!device) return res.status(404).json({ error: 'Device non trouvé' });
  res.json(device);
});

// GET /users/:userId/devices  (montée via server.js)
// Exporté séparément pour être monté sous /users/:userId/devices
router.get('/by-user/:userId', async (req, res) => {
  const devices = await deviceService.getDevicesByUser(req.params.userId);
  res.json(devices);
});

// POST /devices
router.post('/', async (req, res) => {
  try {
    const created = await deviceService.createDevice(req.body);
    res.status(201).json(created);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT /devices/:id
router.put('/:id', async (req, res) => {
  try {
    const updated = await deviceService.updateDevice({ id: req.params.id, ...req.body });
    if (!updated) return res.status(404).json({ error: 'Device non trouvé' });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE /devices/:id
router.delete('/:id', async (req, res) => {
  const deleted = await deviceService.deleteDevice(req.params.id);
  if (!deleted) return res.status(404).json({ error: 'Device non trouvé' });
  res.json({ message: 'Device supprimé avec succès' });
});

module.exports = router;
