/**
 * routes/userRoutes.js
 * Routes REST pour les utilisateurs — délèguent à userService.
 */

const { Router } = require('express');
const userService = require('../services/userService');

const router = Router();

// GET /users
router.get('/', async (req, res) => {
  const users = await userService.getUsers();
  res.json(users);
});

// GET /users/:id
router.get('/:id', async (req, res) => {
  const user = await userService.getUser(req.params.id);
  if (!user) return res.status(404).json({ error: 'Utilisateur non trouvé' });
  res.json(user);
});

// POST /users
router.post('/', async (req, res) => {
  try {
    const created = await userService.createUser(req.body);
    res.status(201).json(created);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT /users/:id
router.put('/:id', async (req, res) => {
  try {
    const updated = await userService.updateUser({ id: req.params.id, ...req.body });
    if (!updated) return res.status(404).json({ error: 'Utilisateur non trouvé' });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE /users/:id  (supprime aussi les devices en cascade)
router.delete('/:id', async (req, res) => {
  const deleted = await userService.deleteUser(req.params.id);
  if (!deleted) return res.status(404).json({ error: 'Utilisateur non trouvé' });
  res.json({ message: 'Utilisateur supprimé avec succès' });
});

module.exports = router;
