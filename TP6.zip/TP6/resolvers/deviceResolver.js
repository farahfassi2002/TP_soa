/**
 * resolvers/deviceResolver.js
 * Résolveurs GraphQL — délèguent à deviceService.
 */

const deviceService = require('../services/deviceService');

module.exports = {
  device:         ({ id })                                           => deviceService.getDevice(id),
  devices:        ()                                                 => deviceService.getDevices(),
  devicesByUser:  ({ userId })                                       => deviceService.getDevicesByUser(userId),
  addDevice:      ({ userId, name, type, serialNumber, status })     => deviceService.createDevice({ userId, name, type, serialNumber, status }),
  updateDevice:   ({ id, name, type, serialNumber, status })        => deviceService.updateDevice({ id, name, type, serialNumber, status }),
  deleteDevice:   ({ id })                                           => deviceService.deleteDevice(id),
};
