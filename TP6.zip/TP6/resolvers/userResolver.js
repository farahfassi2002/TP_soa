/**
 * resolvers/userResolver.js
 * Résolveurs GraphQL — délèguent à userService.
 */

const userService  = require('../services/userService');
const deviceService = require('../services/deviceService');

module.exports = {
  user:       ({ id })                          => userService.getUser(id),
  users:      ()                                => userService.getUsers(),
  addUser:    ({ name, email, password })       => userService.createUser({ name, email, password }),
  updateUser: ({ id, name, email, password })  => userService.updateUser({ id, name, email, password }),
  deleteUser: ({ id })                          => userService.deleteUser(id),

  // Champ imbriqué : User.devices
  // Appelé automatiquement par graphql-http quand le client demande user { devices { ... } }
};
