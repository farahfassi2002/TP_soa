/**
 * producer.js
 * Producteur Kafka : envoie un événement capteur toutes les secondes.
 */

require('dotenv').config();
const { Kafka } = require('kafkajs');

const kafka = new Kafka({
  clientId: 'tp9-producer',
  brokers: [process.env.KAFKA_BROKER || 'localhost:9092'],
});

const producer = kafka.producer();
const topic    = process.env.KAFKA_TOPIC || 'test-topic';

const run = async () => {
  await producer.connect();
  console.log(`✅  Producteur connecté. Envoi sur le topic "${topic}" toutes les secondes...`);

  let count = 0;

  setInterval(async () => {
    count++;
    const event = {
      deviceId:    'sensor-01',
      temperature: Number((20 + Math.random() * 10).toFixed(2)),
      humidity:    Number((40 + Math.random() * 30).toFixed(2)),
      status:      count % 5 === 0 ? 'warning' : 'ok',
      createdAt:   new Date().toISOString(),
    };

    await producer.send({
      topic,
      messages: [{ key: event.deviceId, value: JSON.stringify(event) }],
    });

    console.log(`[#${count}] Message produit →`, event);
  }, 1000);

  // Arrêt propre
  process.on('SIGINT', async () => {
    console.log('\n🛑  Arrêt du producteur...');
    await producer.disconnect();
    process.exit(0);
  });
};

run().catch(console.error);
