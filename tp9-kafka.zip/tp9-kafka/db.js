/**
 * db.js
 * Connexion PostgreSQL et initialisation de la table kafka_messages.
 */

require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     Number(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME     || 'tp9_kafka',
  user:     process.env.DB_USER     || 'postgres',
  password: process.env.DB_PASSWORD || 'yourpassword',
});

/**
 * Crée la table kafka_messages si elle n'existe pas encore.
 */
async function initTable() {
  const sql = `
    CREATE TABLE IF NOT EXISTS kafka_messages (
      id        SERIAL PRIMARY KEY,
      topic     VARCHAR(255)  NOT NULL,
      partition INTEGER       NOT NULL,
      "offset"  BIGINT        NOT NULL,
      key       VARCHAR(255),
      payload   JSONB         NOT NULL,
      received_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `;
  await pool.query(sql);
  console.log('✅  Table kafka_messages prête.');
}

/**
 * Insère un message Kafka dans la base.
 */
async function insertMessage({ topic, partition, offset, key, payload }) {
  const sql = `
    INSERT INTO kafka_messages (topic, partition, "offset", key, payload)
    VALUES ($1, $2, $3, $4, $5)
    RETURNING *;
  `;
  const values = [topic, partition, Number(offset), key ?? null, payload];
  const result = await pool.query(sql, values);
  return result.rows[0];
}

/**
 * Récupère tous les messages (ordre décroissant).
 */
async function getMessages({ limit = 100, offset = 0 } = {}) {
  const sql = `
    SELECT * FROM kafka_messages
    ORDER BY received_at DESC
    LIMIT $1 OFFSET $2;
  `;
  const result = await pool.query(sql, [limit, offset]);
  return result.rows;
}

/**
 * Récupère un message par son ID.
 */
async function getMessageById(id) {
  const result = await pool.query(
    'SELECT * FROM kafka_messages WHERE id = $1',
    [id]
  );
  return result.rows[0] ?? null;
}

module.exports = { pool, initTable, insertMessage, getMessages, getMessageById };
