/**
 * consumer.js
 * Consommateur Kafka : parse les messages JSON et les persiste dans PostgreSQL.
 */

require('dotenv').config();
const { Kafka } = require('kafkajs');
const { initTable, insertMessage } = require('./db');

const kafka = new Kafka({
  clientId: 'tp9-consumer',
  brokers: [process.env.KAFKA_BROKER || 'localhost:9092'],
});

const consumer = kafka.consumer({ groupId: 'tp9-group' });
const topic    = process.env.KAFKA_TOPIC || 'test-topic';

const run = async () => {
  // 1. Initialiser la table PostgreSQL
  await initTable();

  // 2. Connexion et abonnement
  await consumer.connect();
  await consumer.subscribe({ topic, fromBeginning: true });

  console.log(`✅  Consommateur connecté. En écoute sur "${topic}"...`);

  // 3. Traitement de chaque message
  await consumer.run({
    eachMessage: async ({ topic, partition, message }) => {
      const rawValue = message.value?.toString();
      const key      = message.key?.toString() ?? null;
      const offset   = message.offset;

      // Parser le JSON
      let payload;
      try {
        payload = JSON.parse(rawValue);
      } catch {
        console.warn('⚠️  Message non-JSON reçu, ignoré :', rawValue);
        return;
      }

      // Afficher dans la console
      console.log(`[partition=${partition} offset=${offset}]`, {
        key,
        topic,
        payload,
      });

      // Persister dans PostgreSQL
      try {
        const saved = await insertMessage({ topic, partition, offset, key, payload });
        console.log(`💾  Sauvegardé → id=${saved.id}, received_at=${saved.received_at}`);
      } catch (err) {
        console.error('❌  Erreur DB :', err.message);
      }
    },
  });

  // Arrêt propre
  process.on('SIGINT', async () => {
    console.log('\n🛑  Arrêt du consommateur...');
    await consumer.disconnect();
    process.exit(0);
  });
};

run().catch(console.error);
