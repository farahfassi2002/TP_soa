/**
 * server.js
 * API REST Express.js 5 pour consulter les messages Kafka stockés en base.
 */

require('dotenv').config();
const express  = require('express');
const { initTable, getMessages, getMessageById } = require('./db');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// ─── Routes ──────────────────────────────────────────────────────────────────

/**
 * GET /
 * Informations sur l'API.
 */
app.get('/', (req, res) => {
  res.json({
    message: 'TP9 — API Kafka Messages',
    routes: {
      allMessages: 'GET /messages?limit=50&offset=0',
      oneMessage:  'GET /messages/:id',
    },
  });
});

/**
 * GET /messages
 * Retourne tous les messages Kafka stockés en base.
 * Query params: limit (défaut 100), offset (défaut 0)
 */
app.get('/messages', async (req, res) => {
  try {
    const limit  = Math.min(parseInt(req.query.limit)  || 100, 500);
    const offset = parseInt(req.query.offset) || 0;
    const messages = await getMessages({ limit, offset });
    res.json({
      count: messages.length,
      limit,
      offset,
      data: messages,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erreur serveur', detail: err.message });
  }
});

/**
 * GET /messages/:id
 * Retourne un message par son ID PostgreSQL.
 */
app.get('/messages/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'ID invalide' });

    const message = await getMessageById(id);
    if (!message) return res.status(404).json({ error: 'Message non trouvé' });

    res.json(message);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erreur serveur', detail: err.message });
  }
});

// ─── Démarrage ────────────────────────────────────────────────────────────────

const start = async () => {
  await initTable();
  app.listen(PORT, () => {
    console.log(`✅  API REST démarrée → http://localhost:${PORT}`);
    console.log(`   GET /messages       → liste tous les messages`);
    console.log(`   GET /messages/:id   → un message par ID`);
  });
};

start().catch(console.error);
