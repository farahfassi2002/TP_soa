# TP9 — Intégration et Manipulation de Données avec Kafka 4.2

> **Matière :** SoA et Microservices  
> **Enseignant :** Dr. Salah Gontara  
> **Classe :** 4Info — A.U. 2025/2026

---

## Table des matières

1. [Objectifs](#objectifs)
2. [Architecture du projet](#architecture-du-projet)
3. [Technologies utilisées](#technologies-utilisées)
4. [Kafka en mode KRaft](#kafka-en-mode-kraft)
5. [Installation et configuration](#installation-et-configuration)
6. [Structure du code](#structure-du-code)
7. [Base de données PostgreSQL](#base-de-données-postgresql)
8. [Producteur Kafka](#producteur-kafka)
9. [Consommateur Kafka](#consommateur-kafka)
10. [API REST](#api-rest)
11. [Tests du flux complet](#tests-du-flux-complet)
12. [Difficultés rencontrées](#difficultés-rencontrées)
13. [Conclusion](#conclusion)

---

## Objectifs

- Comprendre le fonctionnement d'Apache Kafka 4.2 en mode **KRaft** (sans ZooKeeper).
- Créer un **producteur** Kafka qui émet des événements JSON périodiques.
- Créer un **consommateur** Kafka qui parse les messages et les persiste dans **PostgreSQL**.
- Exposer une **API REST** avec Express.js 5 pour interroger les messages stockés.
- Valider le flux complet : production → consommation → stockage → restitution via API.

---

## Architecture du projet

```
tp9-kafka/
├── producer.js     # Producteur Kafka (événements capteur toutes les secondes)
├── consumer.js     # Consommateur Kafka + persistance PostgreSQL
├── server.js       # API REST Express.js 5 (GET /messages, GET /messages/:id)
├── db.js           # Connexion PostgreSQL, init table, fonctions CRUD
├── .env.example    # Variables d'environnement (à copier en .env)
└── package.json
```

### Schéma du flux de données

```
┌─────────────┐     toutes les 1s     ┌─────────────────┐
│  producer.js│ ─── JSON event ──────▶│  Kafka Broker   │
│  (sensor-01)│                        │  topic:         │
└─────────────┘                        │  test-topic     │
                                       └────────┬────────┘
                                                │ eachMessage
                                       ┌────────▼────────┐
                                       │  consumer.js    │
                                       │  parse JSON     │
                                       │  INSERT → PG    │
                                       └────────┬────────┘
                                                │
                                       ┌────────▼────────┐
                                       │  PostgreSQL     │
                                       │  kafka_messages │
                                       └────────┬────────┘
                                                │ SELECT
                                       ┌────────▼────────┐
                                       │  server.js      │
                                       │  GET /messages  │
                                       └─────────────────┘
```

---

## Technologies utilisées

| Composant | Technologie | Version |
|---|---|---|
| Message broker | Apache Kafka (KRaft) | 4.2 |
| Client Kafka | KafkaJS | ^2.2.4 |
| Serveur HTTP | Express.js | ^5.0.1 |
| Base de données | PostgreSQL | 14+ |
| Client PostgreSQL | node-postgres (pg) | ^8.12.0 |
| Configuration | dotenv | ^16.4.5 |
| Runtime | Node.js | LTS (≥ 18) |

---

## Kafka en mode KRaft

Depuis Kafka 4.x, **ZooKeeper est supprimé**. Kafka gère lui-même ses métadonnées de cluster via un quorum de contrôleurs interne appelé **KRaft** (Kafka Raft).

### Avantages de KRaft

| Ancien mode (ZooKeeper) | Nouveau mode (KRaft) |
|---|---|
| 2 services à démarrer (ZK + Kafka) | 1 seul service |
| Latence accrue par ZooKeeper | Métadonnées directement dans Kafka |
| Maintenance complexe | Configuration simplifiée |
| Limite de partitions ≈ 200k | Supporte des millions de partitions |

---

## Installation et configuration

### Étape 1 — Prérequis

```bash
# Vérifier Java 17+
java -version

# Vérifier Node.js
node -v && npm -v
```

### Étape 2 — Initialiser le stockage KRaft

```bash
# Linux / macOS
KAFKA_CLUSTER_ID="$(bin/kafka-storage.sh random-uuid)"
bin/kafka-storage.sh format --standalone -t "$KAFKA_CLUSTER_ID" -c config/server.properties

# Windows (PowerShell)
$KAFKA_CLUSTER_ID = (.\bin\windows\kafka-storage.bat random-uuid | Select-Object -Last 1)
.\bin\windows\kafka-storage.bat format --standalone -t $KAFKA_CLUSTER_ID -c .\config\server.properties
```

### Étape 3 — Démarrer le broker Kafka

```bash
# Linux
bin/kafka-server-start.sh config/server.properties

# Windows
bin\windows\kafka-server-start.bat config\server.properties
```

### Étape 4 — Créer le topic

```bash
# Linux
bin/kafka-topics.sh --create \
  --partitions 3 \
  --replication-factor 1 \
  --topic test-topic \
  --bootstrap-server localhost:9092

# Vérifier la création
bin/kafka-topics.sh --list --bootstrap-server localhost:9092
```

> `--partitions 3` permet de tester le parallélisme entre plusieurs consommateurs d'un même groupe.

### Étape 5 — Installer les dépendances Node.js

```bash
git clone <url-du-repo>
cd tp9-kafka
npm install
cp .env.example .env
# Éditer .env avec vos paramètres PostgreSQL
```

### Étape 6 — Configurer PostgreSQL

```sql
-- Créer la base de données
CREATE DATABASE tp9_kafka;

-- La table sera créée automatiquement au démarrage du consumer ou de l'API
```

### Variables d'environnement (`.env`)

```env
KAFKA_BROKER=localhost:9092
KAFKA_TOPIC=test-topic

DB_HOST=localhost
DB_PORT=5432
DB_NAME=tp9_kafka
DB_USER=postgres
DB_PASSWORD=yourpassword

PORT=3000
```

---

## Structure du code

### `db.js` — Couche d'accès aux données

Ce module centralise toute interaction avec PostgreSQL :

- **`initTable()`** : crée la table `kafka_messages` si elle n'existe pas.
- **`insertMessage()`** : insère un message Kafka avec ses métadonnées.
- **`getMessages()`** : liste les messages avec pagination.
- **`getMessageById()`** : récupère un message par son ID PostgreSQL.

---

## Base de données PostgreSQL

### Schéma de la table `kafka_messages`

```sql
CREATE TABLE IF NOT EXISTS kafka_messages (
  id          SERIAL PRIMARY KEY,
  topic       VARCHAR(255)  NOT NULL,
  partition   INTEGER       NOT NULL,
  "offset"    BIGINT        NOT NULL,
  key         VARCHAR(255),
  payload     JSONB         NOT NULL,
  received_at TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);
```

| Colonne | Type | Description |
|---|---|---|
| `id` | SERIAL | Identifiant auto-incrémenté PostgreSQL |
| `topic` | VARCHAR | Nom du topic Kafka source |
| `partition` | INTEGER | Numéro de partition Kafka |
| `offset` | BIGINT | Position du message dans la partition |
| `key` | VARCHAR | Clé du message (ex. `sensor-01`) |
| `payload` | JSONB | Corps JSON du message |
| `received_at` | TIMESTAMPTZ | Horodatage d'insertion en base |

Le type **JSONB** permet d'interroger le contenu du payload avec les opérateurs PostgreSQL (`->`, `->>`), par exemple :

```sql
SELECT payload->>'temperature' FROM kafka_messages WHERE key = 'sensor-01';
```

---

## Producteur Kafka

**Fichier :** `producer.js`

Le producteur envoie toutes les secondes un événement JSON simulant un capteur IoT :

```json
{
  "deviceId":    "sensor-01",
  "temperature": 24.73,
  "humidity":    58.12,
  "status":      "ok",
  "createdAt":   "2025-05-10T10:23:45.123Z"
}
```

### Démarrage

```bash
node producer.js
# ou
npm run producer
```

### Sortie console

```
✅  Producteur connecté. Envoi sur le topic "test-topic" toutes les secondes...
[#1] Message produit → { deviceId: 'sensor-01', temperature: 23.41, ... }
[#2] Message produit → { deviceId: 'sensor-01', temperature: 27.89, ... }
```

---

## Consommateur Kafka

**Fichier :** `consumer.js`

Le consommateur :
1. Initialise la table PostgreSQL (`initTable()`).
2. S'abonne au topic `test-topic` depuis le début (`fromBeginning: true`).
3. Pour chaque message : parse le JSON, l'affiche en console, puis l'insère en base via `insertMessage()`.
4. Gère les messages non-JSON avec un `try/catch` (avertissement + skip).

### Démarrage

```bash
node consumer.js
# ou
npm run consumer
```

### Sortie console

```
✅  Table kafka_messages prête.
✅  Consommateur connecté. En écoute sur "test-topic"...
[partition=0 offset=0] { key: 'sensor-01', topic: 'test-topic', payload: { ... } }
💾  Sauvegardé → id=1, received_at=2025-05-10T10:23:46.001Z
```

---

## API REST

**Fichier :** `server.js`

L'API Express.js 5 expose deux routes pour lire les messages stockés.

### Démarrage

```bash
node server.js
# ou
npm run server
```

### Endpoints

#### `GET /messages`

Liste tous les messages avec pagination optionnelle.

**Query params :**
- `limit` (défaut : 100, max : 500)
- `offset` (défaut : 0)

**Exemple :**

```bash
curl http://localhost:3000/messages?limit=5
```

**Réponse :**
```json
{
  "count": 5,
  "limit": 5,
  "offset": 0,
  "data": [
    {
      "id": 10,
      "topic": "test-topic",
      "partition": 2,
      "offset": "9",
      "key": "sensor-01",
      "payload": {
        "deviceId": "sensor-01",
        "temperature": 26.31,
        "humidity": 55.40,
        "status": "ok",
        "createdAt": "2025-05-10T10:23:55.123Z"
      },
      "received_at": "2025-05-10T10:23:55.210Z"
    }
  ]
}
```

---

#### `GET /messages/:id`

Récupère un message par son identifiant PostgreSQL.

**Exemple :**

```bash
curl http://localhost:3000/messages/1
```

**Réponse (200) :**
```json
{
  "id": 1,
  "topic": "test-topic",
  "partition": 0,
  "offset": "0",
  "key": "sensor-01",
  "payload": {
    "deviceId": "sensor-01",
    "temperature": 23.41,
    "humidity": 61.02,
    "status": "ok",
    "createdAt": "2025-05-10T10:23:46.000Z"
  },
  "received_at": "2025-05-10T10:23:46.001Z"
}
```

**Réponse (404) :**
```json
{ "error": "Message non trouvé" }
```

---

## Tests du flux complet

### Procédure de test

Ouvrir **4 terminaux** distincts :

| Terminal | Commande | Rôle |
|---|---|---|
| 1 | `bin/kafka-server-start.sh config/server.properties` | Broker Kafka |
| 2 | `node producer.js` | Production de messages |
| 3 | `node consumer.js` | Consommation + stockage DB |
| 4 | `node server.js` | API REST |

### Tests avec curl

```bash
# 1. Lister les 10 derniers messages
curl "http://localhost:3000/messages?limit=10"

# 2. Récupérer le message ID 1
curl http://localhost:3000/messages/1

# 3. Vérifier directement en PostgreSQL
psql -d tp9_kafka -c "SELECT id, partition, \"offset\", key, received_at FROM kafka_messages ORDER BY id DESC LIMIT 5;"
```

### Vérification PostgreSQL directe

```sql
-- Compter les messages reçus
SELECT COUNT(*) FROM kafka_messages;

-- Température moyenne des capteurs
SELECT AVG((payload->>'temperature')::float) AS avg_temp FROM kafka_messages;

-- Messages en statut warning
SELECT id, payload->>'createdAt' AS ts FROM kafka_messages
WHERE payload->>'status' = 'warning';

-- Répartition par partition
SELECT partition, COUNT(*) FROM kafka_messages GROUP BY partition ORDER BY partition;
```

### Résultats observés

| Test | Résultat |
|---|---|
| Producteur envoie 1 msg/s | ✅ Messages visibles dans la console producteur |
| Consommateur reçoit les messages | ✅ Affichage + insertion DB confirmée |
| `GET /messages` retourne les données | ✅ JSON avec `count`, `limit`, `offset`, `data` |
| `GET /messages/1` retourne le 1er message | ✅ Payload JSON complet |
| `GET /messages/999` (inexistant) | ✅ 404 `"Message non trouvé"` |
| Messages distribués sur 3 partitions | ✅ Vérifiable via la colonne `partition` |

---

## Difficultés rencontrées

| Difficulté | Solution |
|---|---|
| Kafka 4.2 nécessite Java 17+ | Installation de `openjdk-17-jdk` avant Kafka |
| Format KRaft obligatoire avant 1er démarrage | `kafka-storage.sh format --standalone` avec un UUID généré |
| `"offset"` est un mot réservé en PostgreSQL | Entouré de guillemets doubles dans toutes les requêtes SQL |
| Consommateur reçoit les anciens messages au redémarrage | Normal avec `fromBeginning: true` ; changer le `groupId` pour repartir à zéro |
| Express 5 : gestion des erreurs async | `try/catch` explicite dans chaque handler (pas de wrapper nécessaire en Express 5) |
| Message non-JSON dans le topic | Géré par `try/catch` JSON.parse avec skip du message |

---

## Conclusion

Ce TP a permis de mettre en place un pipeline de streaming complet avec Apache Kafka 4.2 :

- La configuration **KRaft** simplifie le déploiement en éliminant ZooKeeper tout en rendant Kafka plus robuste et scalable.
- Le **producteur** simule un flux de données IoT en temps réel, démontrant l'utilisation des topics et des partitions pour le parallélisme.
- Le **consommateur** illustre la consommation fiable de messages avec persistance en base de données relationnelle (PostgreSQL), en stockant les métadonnées Kafka (topic, partition, offset) aux côtés du payload applicatif en JSONB.
- L'**API REST** permet d'interroger l'historique des messages avec pagination, montrant comment Kafka peut alimenter des systèmes de requêtes traditionnels.

Cette architecture constitue la base d'un vrai pipeline de données orienté événements, applicable à des cas réels comme la supervision de capteurs IoT, les logs applicatifs distribués ou la synchronisation de microservices.
